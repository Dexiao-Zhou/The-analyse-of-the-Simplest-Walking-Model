clear all
clc
close all

gamma = 0.008;
steps = 5;

BasinOfAttraction(gamma,steps)

function Basin = BasinOfAttraction(gamma,steps)
B = 0.0000000001; % B is the ratio of the m and M
% set the ran ge of the initial state value
theta_range = linspace(0.15, 0.25, 300); % theta in the range of [0 1] with 100 value 
theta_dot_range = linspace(-0.14, -0.26, 300); % theta_dot in the range of [0 -1.2] with 100 value 
% set a matrix to save the result
basin_of_attraction = zeros(length(theta_range), length(theta_dot_range));

for i = 1:length(theta_range)
    for j = 1:length(theta_dot_range)
        % set the initial condition 
        y0 = [theta_range(i); 
              theta_dot_range(j); 
              2*theta_range(i);
              theta_dot_range(j)*(1-cos(2*theta_range(i)))];
        % simulate to walk
        stable =Walk(gamma,B,steps,y0);
        % Incorporate the number of steps in simulated walking as a parameter into the attractor basin.
        basin_of_attraction(i, j) = stable;        
    end
end

% Drawing the Basin of Attraction
imagesc(theta_range, theta_dot_range, basin_of_attraction');%元素索引的时候并不是按照矩阵进行索引的hi
set(gca, 'YDir', 'normal'); % flip the y-axis
xlabel('theta');
ylabel('theta_{dot}');
title('Basin of Attraction');
colorbar;
end

function stable = Walk(gamma,B,steps,y0)
% Gamma: angle of slope (radians), used by integration function
    per = 5;           % Max number of seconds allowed per step 

% Initialization
y = [];         % Vector to save states
t = [];         % Vector to save times
tci = 0;        % Collision index vector
h = [0 per];	% Integration period in seconds 

% Set integration tolerances, turn on collision detection, add more output points
options = odeset('RelTol',1e-4,'AbsTol',1e-8,'Refine',30,'Events',@collision);

% Loop to perform integration of a noncontinuous function
for i=1:steps
   [tout,yout] = ode45(@(t,y)f(t,y,gamma,B),h,y0,options);   % Integrate for one stride

   y = [y;yout];                                        %#ok<AGROW> % Append states to state vector
   t = [t;tout];                                        %#ok<AGROW> % Append times to time vector
   c2y1 = cos(2*y(end,1));                              % Calculate once for new ICs
 
   y0 = [-y(end,1);
         c2y1*y(end,2);
         -2*y(end,1);
         c2y1*(1-c2y1)*y(end,2)];                       % Mapping to calculate new ICs after collision
   tci = [tci length(t)];                               %#ok<AGROW> % Append collision index to collision index vector
   h = t(end)+[0 per];                                  % New integration period 
%select the walking case of the simulation
   a = abs(round(y(end,3),4)); %condition1: all of the theta must less than 1
   b = abs(round(y(end,1),4)); %condition2: all of the phi must less than 1
   y1 = y(:,3);
   c = zeros(steps);
   for j=1:steps
       c(j) = abs(y1(floor(length(y1)/j)));
   end
% phi=2*theta, all of the angle must less than 1 radian
   if a==2*b && t(end)~=i*per && all(c(:) < 3) && a<1 && t(end)>3*steps

            % Phase plot of phi versus theta
            % figure(4)
            % plot(y(:,1),y(:,3))
            % grid on
            % title('Phase Portrait')
            % xlabel('\theta(t) (rad.)')
            % ylabel('\phi(t) (rad.)')
            % wmview(y,gamma,tci)
            % close

            stable = i;
            break;
   end
    stable = 0;         
end

end

function ydot=f(t,y,gamma,B)  
% y: [theta; dot_theta; phi; dot_phi]
% gamma: slope of incline (radians)
% B: ratio foot mass to hip mass
   
L=12;
g=9.8;

Mmatrix = [1+2*B*(1-cos(y(3))),-B*(1-cos(y(3)));B*(1-cos(y(3))),-B];
Cmatrix = [-B*sin(y(3))*(y(4)^2-2*y(2)*y(4));B*y(2)^2*sin(y(3))];
Gmatrix = [(B*g/L*(sin(y(1)-y(3)-gamma)-sin(y(1)-gamma)))-g/L*sin(y(1)-gamma);(B*g/L)*sin(y(1)-y(3)-gamma)];

Minv = inv(Mmatrix);

eqn = Minv*(-Cmatrix-Gmatrix);

ydot = [y(2); %dot_theta
        eqn(1);
        y(4);
        eqn(2)];

end
function [value,isterminal,direction]=collision(t,y)   %events function
% Check for heelstrike collision using zero-crossing detection
value = y(3)-2*y(1);    	% when phi-2*theta==0 Geometric collision condition
isterminal = 1;				% Stop integrating if collision found
direction = 1;				% Condition only true when passing from - to +
end